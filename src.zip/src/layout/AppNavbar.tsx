import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import dayjs from "dayjs";

const DAYS = ["SUN", "MON", "TUE", "WED", "THU", "FRI", "SAT"];

export default function AppNavbar() {
  const navigate = useNavigate();
  const [time, setTime] = useState("");
  const [date, setDate] = useState<Date | null>(null);

  useEffect(() => {
    const update = () => {
      const now = dayjs();
      setTime(now.format("HH:mm:ss"));
      setDate(now.toDate());
    };
    update();
    const interval = setInterval(update, 1000);
    return () => clearInterval(interval);
  }, []);

  const formattedDate = date
    ? `${DAYS[date.getDay()]} . ${dayjs(date).format("DD MMM YYYY")}`
    : "";

  return (
    <nav className="grid grid-cols-[1fr_auto_1fr] items-center border-b border-border px-6 py-3">
      {/* Logo */}
      <div
        className="flex flex-col border-r border-border pr-8 cursor-pointer"
        onClick={() => navigate("/")}
      >
        <h1 className="text-lg uppercase tracking-wide font-heading">
          DAWN<span className="text-[var(--dawn-burnt)]">-</span>01
        </h1>
        <div className="flex items-center gap-3 text-xs font-mono uppercase opacity-75">
          <span>// local infrastructure</span>
          <span>·</span>
          <span>node 01</span>
          <span>·</span>
          <span>mission active</span>
        </div>
      </div>

      {/* Métriques */}
      <div className="flex items-center gap-8 border-r border-border px-8 justify-self-center">
        <div className="flex flex-col gap-1">
          <span className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">
            Hostname
          </span>
          <span className="font-mono text-sm">dawn.local</span>
        </div>
        <div className="flex flex-col gap-1">
          <span className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">
            Uptime
          </span>
          <span className="font-mono text-sm">14d 06h</span>
        </div>
        <div className="flex flex-col gap-1">
          <span className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">
            Services
          </span>
          <span className="font-mono text-sm">8 ONLINE · 0 DOWN</span>
        </div>
      </div>

      {/* Horloge + statut */}
      <div className="flex items-center gap-6 justify-self-end">
        <div className="flex flex-col items-end border-r border-border pr-6">
          <div className="flex items-center gap-2">
            <span className="font-mono text-xl">{time}</span>
            <span className="h-[1em] w-[15px] bg-[var(--dawn-burnt)] animate-[blink_1s_step-end_infinite]" />
          </div>
          <span className="font-mono text-xs opacity-75">{formattedDate}</span>
        </div>
        <div className="flex items-center gap-2 text-xs uppercase">
          <span>nominal</span>
          <span className="h-2 w-2 rounded-full bg-[var(--dawn-crt-green)]" />
        </div>
      </div>
    </nav>
  );
}
