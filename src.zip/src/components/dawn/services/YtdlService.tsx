import { useEffect, useRef, useState, type ClipboardEvent } from "react";

type JobStatus = "pending" | "downloading" | "done" | "error";

interface Job {
  status: JobStatus;
  progress: number;
  speed?: string | null;
  eta?: string | null;
  title?: string | null;
  error?: string;
}

const STATUS_LABEL: Record<JobStatus, string> = {
  pending: "PENDING",
  downloading: "DOWNLOADING",
  done: "DONE",
  error: "ERROR",
};

const STATUS_CLASS: Record<JobStatus, string> = {
  pending: "ytdlService-pending",
  downloading: "ytdlService-running",
  done: "ytdlService-done",
  error: "ytdlService-error",
};

export default function YtdlService() {
  const [url, setUrl] = useState("");
  const [format, setFormat] = useState<"mp3" | "mp4">("mp3");
  const [quality, setQuality] = useState("best");
  const [job, setJob] = useState<Job | null>(null);
  const jobId = useRef<string | null>(null);
  const pollTimer = useRef<ReturnType<typeof setInterval>>(undefined);

  const isRunning = !!job && (job.status === "pending" || job.status === "downloading");
  const canStart = url.trim().length > 0 && !isRunning;

  useEffect(() => () => clearInterval(pollTimer.current), []);

  const startPolling = () => {
    pollTimer.current = setInterval(async () => {
      try {
        const res = await fetch(`/api/ytdl/progress/${jobId.current}`);
        const data: Job = await res.json();
        setJob(data);
        if (data.status === "done" || data.status === "error") {
          clearInterval(pollTimer.current);
        }
      } catch {
        clearInterval(pollTimer.current);
        setJob((prev) => (prev ? { ...prev, status: "error" } : prev));
      }
    }, 800);
  };

  const startDownload = async () => {
    if (!canStart) return;
    setJob({ status: "pending", progress: 0, speed: null, eta: null, title: null });

    try {
      const res = await fetch("/api/ytdl/start", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url: url.trim(), format, quality }),
      });
      if (!res.ok) throw new Error("Request failed");
      const data = await res.json();
      jobId.current = data.job_id;
      startPolling();
    } catch {
      setJob({ status: "error", progress: 0, error: "Request failed" });
    }
  };

  const downloadFile = () => {
    if (jobId.current) window.location.href = `/api/ytdl/file/${jobId.current}`;
  };

  const reset = async () => {
    if (jobId.current) {
      await fetch(`/api/ytdl/${jobId.current}`, { method: "DELETE" }).catch(() => {});
    }
    jobId.current = null;
    setJob(null);
    setUrl("");
  };

  const onPaste = (e: ClipboardEvent<HTMLInputElement>) => {
    const text = e.clipboardData?.getData("text") ?? "";
    if (/youtube\.com|youtu\.be/.test(text)) {
      setUrl(text);
      e.preventDefault();
    }
  };

  return (
    <div className="ytdlService-service">
      <div className="ytdlService-header">
        <div className="ytdlService-title">
          <span className="ytdlService-icon" aria-hidden="true">▶</span>
          YT EXTRACTOR
        </div>
        <div className={`ytdlService-status ${job ? STATUS_CLASS[job.status] : "ytdlService-idle"}`}>
          <span className="ytdlService-dot" />
          {job ? STATUS_LABEL[job.status] : "IDLE"}
        </div>
      </div>

      <div className="ytdlService-inputRow">
        <input
          value={url}
          onChange={(e) => setUrl(e.target.value)}
          onPaste={onPaste}
          type="text"
          className="ytdlService-input"
          placeholder="https://youtube.com/watch?v=..."
          disabled={isRunning}
        />
      </div>

      <div className="ytdlService-controls">
        <div className="ytdlService-formatTabs">
          <button
            className={`ytdlService-tab ${format === "mp3" ? "ytdlService-active" : ""}`}
            disabled={isRunning}
            onClick={() => setFormat("mp3")}
          >
            MP3
          </button>
          <button
            className={`ytdlService-tab ${format === "mp4" ? "ytdlService-active" : ""}`}
            disabled={isRunning}
            onClick={() => setFormat("mp4")}
          >
            MP4
          </button>
        </div>

        {format === "mp4" && (
          <select
            value={quality}
            onChange={(e) => setQuality(e.target.value)}
            className="ytdlService-select"
            disabled={isRunning}
          >
            <option value="best">BEST</option>
            <option value="1080">1080p</option>
            <option value="720">720p</option>
            <option value="480">480p</option>
          </select>
        )}

        <button className="ytdlService-submit" disabled={!canStart} onClick={startDownload}>
          {!isRunning ? "EXTRACT" : <span className="ytdlService-spinner">RUNNING</span>}
        </button>
      </div>

      {job && (
        <div className="ytdlService-progress">
          {job.title && <div className="ytdlService-trackTitle">{job.title}</div>}

          <div className="ytdlService-barRow">
            <div className="ytdlService-barTrack">
              <div
                className={`ytdlService-barFill ${job.status === "done" ? "ytdlService-barDone" : ""} ${
                  job.status === "error" ? "ytdlService-barError" : ""
                }`}
                style={{ width: `${job.progress}%` }}
              />
            </div>
            <span className="ytdlService-pct">{Math.round(job.progress)}%</span>
          </div>

          <div className="ytdlService-meta">
            {job.speed && (
              <span>
                <span className="ytdlService-lbl">SPD</span> {job.speed}
              </span>
            )}
            {job.eta && (
              <span>
                <span className="ytdlService-lbl">ETA</span> {job.eta}
              </span>
            )}
            {job.status === "error" && <span className="ytdlService-errorMsg">⚠ {job.error}</span>}
          </div>

          {job.status === "done" && (
            <div className="ytdlService-doneRow">
              <button className="ytdlService-saveBtn" onClick={downloadFile}>
                ↓ SAVE {format.toUpperCase()}
              </button>
              <button className="ytdlService-resetBtn" onClick={reset}>
                NEW
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
