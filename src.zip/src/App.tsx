import { Route, Routes, useNavigate } from "react-router-dom";
import AppNavbar from "@/layout/AppNavbar";
import HomeNavbar from "@/layout/HomeNavbar";
import TerminalShell from "./components/dawn/terminal/TerminalShell";
import PostIt from "./components/dawn/PostIt";
import ServiceGrid from "./components/dawn/ServiceGrid";
import HomeBottomBar from "./components/dawn/HomeBottomBar";
import YtdlService from "./components/dawn/services/YtdlService";

function HomePage() {
  const navigate = useNavigate();

  return (
    <div className="flex min-h-screen items-center justify-center bg-[var(--color-room)] p-6">
      <div className="panel home-panel">
        <div className="panel-vignette" />
        <div className="panel-bevel" />

        <HomeNavbar />

        <div className="grid grid-cols-1 items-stretch gap-4 lg:grid-cols-[1.42fr_1fr]">
          <TerminalShell />
          <ServiceGrid onNavigate={(route) => navigate(`/${route}`)} />
        </div>

        <HomeBottomBar />

        <PostIt />
      </div>
    </div>
  );
}

function YtdlPage() {
  return (
    <div className="flex h-screen flex-col">
      <AppNavbar />
      <div className="flex-1 overflow-auto p-8">
        <YtdlService />
      </div>
    </div>
  );
}

function App() {
  return (
    <Routes>
      <Route path="/" element={<HomePage />} />
      <Route path="/ytdl" element={<YtdlPage />} />
    </Routes>
  );
}

export default App;
